package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_08_StartsWithXpathExp {

	public static void main(String[] args) {
		
		//Launch chrome web browser
		System.setProperty("web driver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
						
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.saucedemo.com/");
		
		driver.findElement(By.xpath("//input[starts-with(@name,'user')]")).sendKeys("standard_user");
		
		driver.findElement(By.xpath("//input[starts-with(@id,'password')]")).sendKeys("secret_sauce");
		
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		
		driver.quit();
		
		System.out.println("Succesfully run");
	}
}
