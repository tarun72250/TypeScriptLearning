package myPackage;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class A_18_UploadFile {

	public static void main(String[] args) throws AWTException {

		//launch chrome browser 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		//maxmize browser
		driver.manage().window().maximize();
		
		//open url
		driver.get("https://demoqa.com/upload-download");
		
		//1. find webelement choose file , //if type=file in web element so we used sendKeys() 
		/*driver.findElement(By.xpath("//input[@id='uploadFile']")).sendKeys("C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\A_18_Selenium Demo task.txt");*/
		
		//2way to upload file using Robot class 
		WebElement button =  driver.findElement(By.xpath("//input[@id='uploadFile']"));
		
		Actions act = new Actions(driver);
		act.moveToElement(button).click().perform();
		
		Robot rb = new Robot();
		rb.delay(2000);
		
		StringSelection ss = new StringSelection("C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\A_18_Selenium Demo task.txt");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		
		//perform   control + action to paste file 
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_K);
		
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_K);
		
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		
		
	}

}
