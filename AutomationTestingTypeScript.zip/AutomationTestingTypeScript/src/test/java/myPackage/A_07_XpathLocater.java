package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_07_XpathLocater {

	public static void main(String[] args) {
		
				//Launch chrome web browser
				System.setProperty("web driver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
								
				WebDriver driver = new ChromeDriver();
				
				driver.get("https://www.saucedemo.com/");
				
				//Locate username by single attribute
				//driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");;
				driver.findElement(By.xpath("//input[contains(@id,'user')]")).sendKeys("standard_user");
				
				
				//Locate pwd using multiple attribute
				//* = whole page search
				//
				driver.findElement(By.xpath("//*[@id='password'][@name='password']")).sendKeys("secret_sauce");
				//Both working 
				//driver.findElement(By.xpath("//*[@id='password']")).sendKeys("secret_sauce");
				
				
				//Locate Login Button 
				driver.findElement(By.xpath("//input[@id='login-button']")).click();
			
				//switch to product page 
				//add to cart
				String currentWindowHandle = driver.getWindowHandle();
				driver.switchTo().window(currentWindowHandle);
				driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-backpack' and @name='add-to-cart-sauce-labs-backpack']")).click();
				driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-bike-light' or @name='add-to-cart-sauce-labs-bike-light']")).click();
				
				 
				
				
				
	}
}
