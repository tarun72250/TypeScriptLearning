package myPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_34_DatePicker {

	public static void main(String[] args) {
		
		//18-May-2000
		String expectedDay = "18";
		String expectedMonthYear = "May 2000";
		
		
		//launch chrome web browser 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//maxmize browser 
		driver.manage().window().maximize();
		
		//open url 
		driver.get("https://www.redbus.in/");
		
		//find date picker webelement to perform click aaction 
		WebElement datePicker =  driver.findElement(By.id("onwardCal"));
		datePicker.click();
	
		while(true)
		{
			String calenderMonthYear =  driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
			
			if(calenderMonthYear.equals(expectedMonthYear))
			{
				
					driver.findElement(By.xpath("//td[text()='"+expectedDay+"']"));
			}
			else
			{
				driver.findElement(By.xpath("//td[@class='next']")).click();			
			}
		}
		
	}
}
