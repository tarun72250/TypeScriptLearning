package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_27_JavaScriptExe {

	public static void main(String[] args) {
		
		
		//Launch chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url 
		driver.get("http://uitestpractice.com/Students/Index");
		
		//js instance create  
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		//enter text in search box 
		js.executeScript("document.getElementById('Search_Data').value='Aliya';");
			
		//click on find element
		WebElement element =  driver.findElement(By.xpath("//input[@value='find']"));
		js.executeScript("arguments[0].click();",element);
		
		//refresh browser
		js.executeScript("history.go(0)");
		
		//get domain name 
		String domain =  js.executeScript("return document.domain;").toString();
		System.out.println("Domain :"+domain);
		
		//get title name 
		String title =  js.executeScript("return document.title;").toString();
		System.out.println("title :"+title);
				
		//get url name 
		String url =  js.executeScript("return document.URL;").toString();
		System.out.println("URL :"+url);
				
		//to draw border around element  
		js.executeScript("arguments[0].style.border = '3px solid red';",element);
		
		//to Zoom page 
		js.executeScript("document.body.style.zoom='50%'");
		
		//to get the height the height and width of a web page.
		System.out.println(js.executeScript("return window.innerHeight;").toString());
		System.out.println(js.executeScript("return window.innerWidth;").toString());
		
		//to perform scroll on js executer 
		//scroll vertically till the end 
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		
		//scroll vertically page up 
		js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
		
		
		//to generate alert pop window in selenium webdriver
		js.executeScript("alert('Alert message.')");
		
		//to navigate different page using javascript 
		js.executeScript("window.location = 'http://www.google.com'");
		
		//
		
		
		
	}
}
