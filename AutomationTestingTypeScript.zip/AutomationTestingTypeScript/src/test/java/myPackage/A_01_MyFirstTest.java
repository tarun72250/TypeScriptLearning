package myPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_01_MyFirstTest {

	public static void main(String[] args) {
		
		//launch web browser
		System.setProperty("web driver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Sillenium + Java Practise\\Divers\\UpdaterSetup.exe");

		WebDriver driver = new ChromeDriver();
		
		//launch google web page 
		driver.navigate().to("http:\\www.google.com");
		
		//capture title of webpage and print 
		String title = driver.getTitle();
		
		System.out.println("Page Title :-"+title);
		
		//Capture URL of the WebPage 
		System.out.println("URL :-"+driver.getCurrentUrl());
		
		//capture page source
		System.out.println("Page Source :- "+driver.getPageSource());
		
		driver.close();
	}
}
