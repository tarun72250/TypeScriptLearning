package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class A_30_NestedIframeDemo {

	public static void main(String[] args) {
		
		//Launch chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url 
		driver.get("https://chercher.tech/");
		driver.switchTo().frame("frame1");
		driver.switchTo().frame("frame3");
			
		//find web element
		driver.findElement(By.id("a")).click();
		
		//switch to parent frame 
		driver.switchTo().parentFrame();
		
		//find web element input box 
		driver.findElement(By.tagName("input")).sendKeys("this is a tx tmsg");
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("frame2");
		
		//find web element anmal dropdown
		WebElement dropDOwnElement =  driver.findElement(By.id("animals"));
		Select dropDown = new Select(dropDOwnElement);
		
		dropDown.selectByVisibleText("Avatar");
		
		
	}
}
