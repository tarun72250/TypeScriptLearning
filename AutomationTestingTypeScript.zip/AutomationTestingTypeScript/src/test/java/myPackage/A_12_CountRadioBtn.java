/*package myPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_12_CountRadioBtn {

	public static void main(String[] args) {
		
		//launch the browser 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
	
		WebDriver driver = new ChromeDriver();
	
		//Maximize browser
		driver.manage().window().maximize();
		
		//open url 
		driver.get("https://udyamregistration.gov.in/Udyam_Login.aspx");
		
		List<WebElement> radioButtonList =  driver.findElements(By.xpath("//input[@type='radio']"));
		
		System.out.println("Total no of radio button on web page :-  "+radioButtonList.size());
		
		driver.close();
	}
}*/

package myPackage;

import java.net.SocketException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_12_CountRadioBtn {

    public static void main(String[] args) throws SocketException {

        WebDriver driver = null;

        try {
            // Set the path for the ChromeDriver executable
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");

            // Initialize the WebDriver
            driver = new ChromeDriver();

            // Maximize browser window
            driver.manage().window().maximize();

            // Open the URL
            //driver.get("https://udyamregistration.gov.in/Udyam_Login.aspx");
            driver.get("https://www.calculator.net");
            
            // Find all radio buttons on the page
            List<WebElement> radioButtonList = driver.findElements(By.xpath("//input[@type='radio']"));

            // Print the total number of radio buttons found
            System.out.println("Total no of radio buttons on the web page: " + radioButtonList.size());

        } 
        catch (Exception e) 
        {
            System.out.println("An error occurred: " + e.getMessage());
        } 
        finally 
        {
            // Close the browser, ensuring it happens even if an exception occurs
            if (driver != null) 
            {
                driver.quit();
            }
        }
    }
}

