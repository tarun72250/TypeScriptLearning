package myPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_04_SelectAnchorTag {

	public static void main(String[] args) {
		
		//Launch chrome web browser
		System.setProperty("web driver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
						
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.saucedemo.com/");
		
		//Locate username by id 
		driver.findElement(By.id("user-name"));
		driver.findElement(By.id("user-name")).sendKeys("standard_user");

		//Locate pwd by name
		driver.findElement(By.name("password"));
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		
		//Locate Login Button 
		driver.findElement(By.className("btn_action")).click();
		
		//Switch to product page
		String currentWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(currentWindowHandle);
		
		//Using Linnk text fully :- Locate Sauce Labs Bolt T-Shirt link 
		//driver.findElement(By.linkText("Sauce Labs Bolt T-Shirt")).click();
		
		//Usinng partially link text 
		//driver.findElement(By.partialLinkText(" Labs ")).click();//by defaault it return first element if there is multiple element.
		//findElement() return single value
		
		//findElement() return multiple values 
		List<WebElement> elementList =  driver.findElements(By.partialLinkText(" Sauce "));//by defalt it return multiple element.

		System.out.println("Element size :-"+elementList.size());
		
	}
}
