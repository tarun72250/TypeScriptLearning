package myPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_35_DatePicker {

	public static void main(String[] args) {
		
	
				//31-March-2022
				String expectedDay = "2";
				String expectedMonth = "May";
				String expectedYear = "2000";
				
				
				//launch chrome web browser 
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				
				//maxmize browser 
				driver.manage().window().maximize();
				
				//open url 
				driver.get("https://www.goibibo.com/");
				
				//switch to iframe 
//				driver.switchTo().frame(0);
				
				//find date picker webelement to perform click aaction 
				WebElement datePicker =  driver.findElement(By.xpath("div[class='sc-12foipm-20 jPzQOy'] p[class='sc-12foipm-4 czGBLf fswWidgetTitle']"));
				datePicker.click();
				
				while(true)
				{
					String calenderMonth =  driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
					String calenderYear = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
					
					if(calenderMonth.equals(expectedMonth) && calenderYear.equals(expectedYear))
					{
						 List<WebElement> dayList =  driver.findElements(By.xpath("//table/tbody/tr/td"));
						 
						 for(WebElement e : dayList)
						 {
							String calenderDay = e.getText();
							if(calenderDay.equals(expectedDay))
							{
								e.click();
								break;
							}
						 }
						 break;
					}
					
					else
					{
						driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();			
					}
				}
		
		
	}
}
