package myPackage;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_23_CaptureScreenShots {

	public static void main(String[] args) throws IOException {
		
		//Launch chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url 
		driver.get("http://uitestpractice.com/");
		
		//capture full page screenshot 
		//step1 : onvert webdriver object to TakeScreenshot interface 
		//TakesScreenshot screenshot = ((TakesScreenshot)driver);
		
		//step 2: call getScreenshotAs method to create image file 
		//File src =  screenshot.getScreenshotAs(OutputType.FILE);
		//File dest = new File("C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Screenshots\\fullPage.png");
		
		//step 3: copy image file to destination
		//FileUtils.copyFile(src, dest);
		
		//=========================================================================================
		
		//we are taking ss or particular webElement :- 
		
		WebElement section = driver.findElement(By.xpath("//div[@class='container red']"));
		
		File src =  section.getScreenshotAs(OutputType.FILE);
		File dest = new File("C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Screenshots\\section1.png");
		
		FileUtils.copyFile(src, dest);
		
	}
}
;