package myPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_20_WebTable {

	public static void main(String[] args) {
		
		
		
		//lUNCH WEB BROWSER 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
				
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
				
		//open url 
		driver.get("C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\A_20_sampletable.html");
		
		//==========================================================================================================================
		//total no of rows and columns
		 // Locate the table element
        WebElement table = driver.findElement(By.tagName("table"));

        // Count total rows (includes <thead>, <tbody>, <tfoot>)
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        System.out.println("Total number of rows: " + rows.size());

        // Count total columns (assume columns are defined in the first row)
        List<WebElement> columns = rows.get(0).findElements(By.tagName("th"));
        System.out.println("Total number of columns: " + columns.size());

        // Close the browser
        driver.quit();

		//==========================================================================================================================
        
        
	}
}
