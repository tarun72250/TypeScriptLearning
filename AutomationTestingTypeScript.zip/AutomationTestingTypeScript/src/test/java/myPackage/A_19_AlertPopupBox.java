package myPackage;

import java.awt.Window;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_19_AlertPopupBox {

	public static void main(String[] args) {
		
		//lUNCH WEB BROWSER 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url 
		driver.get("https://www.w3schools.com/js/js_popup.asp");
		
		//find alert button perform click action.
		driver.findElement(By.xpath("//a[@href='tryit.asp?filename=tryjs_alert']")).click();
		
		//switch to alert window and accept the alert 
		driver.switchTo().alert().accept(); //ok button is clicked
		
		
		//=====================================================================================
		
		//confirm button clicked 
		//find alert button perform click action.
		driver.findElement(By.xpath("//button[@id='confirm']")).click();
				
		//switch to alert window and cancel the alert 
//		driver.switchTo().alert().accept(); //ok button is clicked
		driver.switchTo().alert().dismiss(); //cancel button is clicked
		
		//=====================================================================================
		
		//prompt button clicked
		//find alert button perform click action.
		driver.findElement(By.xpath("//button[@id='prompt']")).click();
						
		//switch to alert window and enter the name
//		driver.switchTo().alert().accept(); //ok button is clicked
		driver.switchTo().alert().sendKeys("Tarun");
		driver.switchTo().alert().dismiss(); //cancel button is clicked
		
		
		

				
				
	}
}