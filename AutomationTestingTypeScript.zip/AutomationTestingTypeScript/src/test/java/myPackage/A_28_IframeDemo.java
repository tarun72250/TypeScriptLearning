package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_28_IframeDemo {

	public static void main(String[] args) {
		
		//Launch chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url 
		driver.get("https://www.rediff.com/");
		
		//switch to iframe moneyiframe
		driver.switchTo().frame("moneyiframe");
		
		//find web element 
		String nseindex = driver.findElement(By.id("nseindex")).getText();
		
		System.out.println(nseindex);
		
	}
}
