package myPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.managers.ChromeDriverManager;

public class A_36_WebDriverMangmt {

	public static void main(String[] args) {
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver =new ChromeDriver();
		
		//max browser 
		driver.manage().window().maximize();
		//open url 
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth/");
		
		
		
		
		
	}
}
