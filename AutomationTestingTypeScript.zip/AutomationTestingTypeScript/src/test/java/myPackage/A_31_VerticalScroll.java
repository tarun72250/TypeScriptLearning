package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_31_VerticalScroll {

	public static void main(String[] args) {
		
		//launch chrome web browser 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//maxmize browser 
		driver.manage().window().maximize();
		
		//open url 
		driver.get("https://www.calculator.net/");
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		//1. to scroll down the web page 
		js.executeScript("window.scrollBy(0,500)");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		js.executeScript("window.scrollBy(0,1000)");

		//to scroll till visibiility of web element 
//		WebElement element = driver.findElement(By.linkText("BMI Calculator"));
//		js.executeScript("arguments[0].scrollIntoView();",element);
//		
		
		//to scroll down the web page at the bottom of the page 
//		js.executeScript("window.scrollTo(0,document.body.scrollHeight)", element);
		
		//Horizontal scroll on the web page 
		WebElement element = driver.findElement(By.id("a7"));
		js.executeScript("arguments[0].scrollIntoView();",element);
		
		
	}
}
