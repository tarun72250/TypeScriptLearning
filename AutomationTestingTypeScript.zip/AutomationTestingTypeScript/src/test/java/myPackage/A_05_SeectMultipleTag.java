package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_05_SeectMultipleTag {

	public static void main(String[] args) {
		
		//launch chrome browser 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.saucedemo.com");
		
		//Locate username -----tag#id
		driver.findElement(By.cssSelector("input#user-name")).sendKeys("standard_user");
		
		//Locate password -tag[attribute=value]
		driver.findElement(By.cssSelector("input[name=password]")).sendKeys("secret_sauce");
		
		//Locate login button using tag.value of className
		driver.findElement(By.cssSelector("input.submit-button")).click();
		
		//Switch to product page
		String currentWindowHandle =  driver.getWindowHandle();
		driver.switchTo().window(currentWindowHandle);
		
		//for product add tp cart code 
		//tag.valueClass[attribute=value]
		driver.findElement(By.cssSelector("button.btn[name='add-to-cart-sauce-labs-backpack']")).click();

		
		
		
		
		
	}
}
