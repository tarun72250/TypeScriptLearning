package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_02_TC_Xpath_Locater {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe" );
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.saucedemo.com/");
		
		//Locate username by id 
		driver.findElement(By.id("user-name"));
		driver.findElement(By.id("user-name")).sendKeys("standard_user");

		//Locate pwd by name
		driver.findElement(By.name("password"));
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		
		//Locate Login Button 
		driver.findElement(By.className("btn_action")).click();
		
		
		

	}

}
