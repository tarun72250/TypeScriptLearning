package myPackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_24_OpenNewTabInWindow {

	public static void main(String[] args) {
		
				//Launch chrome driver
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
				
				WebDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				
				//open url 
				driver.get("http://www.google.com/");
				System.out.println("First page :- "+driver.getTitle());
				
				
				//open new tab 
//				driver.switchTo().newWindow(WindowType.TAB);
				//open new window
				driver.switchTo().newWindow(WindowType.WINDOW);
				
				driver.get("https://facebook.com/");
				System.out.println("Second tab :- "+driver.getTitle());
				
				//get window andles of open windows 
				Set<String> windowHandles =  driver.getWindowHandles();
				List<String> handles = new ArrayList<String>();
				handles.addAll(windowHandles);
				
				driver.close();
				
				driver.switchTo().window(handles.get(0));//switch to google.com
				System.out.println("First page :-"+driver.getTitle());
	}
}
