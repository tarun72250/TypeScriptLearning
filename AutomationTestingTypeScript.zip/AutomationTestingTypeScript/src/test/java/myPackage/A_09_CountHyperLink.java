package myPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_09_CountHyperLink {

	public static void main(String[] args) {
		
		//Launch chrome browser 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.calculator.net");
		
		List<WebElement> linkElements =  driver.findElements(By.tagName("a"));
		System.out.println("Total  Links on webPage :="+linkElements.size());

		for(WebElement el : linkElements)
		{
			System.out.println(el.getText());
		}
		driver.close();
	}
}
