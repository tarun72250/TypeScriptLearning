package myPackage;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class A_32_FileUploadAutoIt {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		
				//launch chrome web browser 
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				
				//maxmize browser 
				driver.manage().window().maximize();
				
				//open url 
				driver.get("https://the-internet.herokuapp.com/upload");
								
				//find choose file web element 
				WebElement button =  driver.findElement(By.id("file-upload"));
				
				Actions act = new Actions(driver);
				act.moveToElement(button).click().perform();
				
				try {
					Runtime.getRuntime().exec("C://Users//Tarun//Desktop//Selenium + Java Practise//FileUpload1.exe" + " " + "C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Resume.txt");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
	}
}
