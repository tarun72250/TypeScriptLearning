package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_29_IframeDemo2 {

	public static void main(String[] args) {
		
				//Launch chrome driver
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
				
				WebDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				
				//open url 
				driver.get("https://www.selenium.dev/selenium/docs/api/java/index.html?overview-summary.html/");
				
				//switch to 1st frame moneyiframe
//				driver.switchTo().frame(0);
//				driver.switchTo().frame("packageListFrame");
//				WebElement iframeElement = driver.findElement(By.name("packageListFrame"));
//				driver.switchTo().frame(iframeElement);

				//locate web element 
//				driver.findElement(By.linkText("org.openqa.selenium")).click();
				
				//switch to main page 
				driver.switchTo().defaultContent();//main page 
				
				
				//switch to 2nd frame 
				driver.switchTo().frame(1);
				
				//find web element "Alert" link text of 2nd frame 
//				driver.findElement(By.linkText("Alert")).click();
				
				//find and print total iframes on web page 
				int noOfIframes =  driver.findElements(By.tagName("iframe")).size();
				System.out.println("Iframes :- "+noOfIframes);
	}
}
