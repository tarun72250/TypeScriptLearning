package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class KestralProDemoo {

	public static void main(String[] args) {
		
		//launch the browser 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://qa-mf.kestrelpro.ai/");
		
		driver.findElement(By.id(":Rclkn:")).sendKeys("kt@yopmail.com");
		
		driver.findElement(By.id(":Rklkn:")).sendKeys("KestrelPro@123");
		
		driver.findElement(By.xpath("//button[normalize-space()='Sign in with password']")).click();
		
//1		driver.findElement(By.id(":r0:")).click();
		
//		driver.findElement(By.xpath("//div[@class='menu-open flex flex-col gap-2']//a[2]//div[1]]")).click();

	}
}
