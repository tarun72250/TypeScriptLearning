package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_03_TC_Xpath_tagName {

	public static void main(String[] args) {
		
		//Launch chrome web browser
		System.setProperty("web driver.chrome.driver", "C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
				
//		WebDriver driver = new ChromeDriver();
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.saucedemo.com");
		
		//Locate username by id 
		driver.findElement(By.tagName("input")).sendKeys("standard_user");

		//Locate pwd by name
		//driver.findElement(By.name("password")).sendKeys("secret_sauce");
		driver.findElement(By.tagName("input")).sendKeys("secret_sauce");//which is incorrect because same tagName for username and password.

		
		//Locate Login Button 
		driver.findElement(By.id("login-button")).click();

	}
}
