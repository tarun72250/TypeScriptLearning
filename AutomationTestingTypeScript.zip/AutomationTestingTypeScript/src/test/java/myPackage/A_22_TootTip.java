package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_22_TootTip {

	public static void main(String[] args) {
		
		//lUNCH WEB BROWSER 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
				
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
				
		//open url 
		//driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.get("https:www.facebook.com/");

		//find sign up web element
		String actualToolTip =  driver.findElement(By.xpath("//a[href='/reg/']")).getAttribute("title");
		
		String expectedToolTip ="Facebook - log in or Sign up";
		
		if(actualToolTip.equals(expectedToolTip))
		{
			System.out.println("Test passed");
		}
		else
		{
			System.out.println("Test Failed");
		}
	}
}
