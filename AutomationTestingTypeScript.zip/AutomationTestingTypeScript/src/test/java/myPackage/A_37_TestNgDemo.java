package myPackage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

//Run all 
public class A_37_TestNgDemo {

	@Test
	public void verifyPageTitle()
	{
		//launch chrome browser 
		WebDriverManager.chromedriver().browserVersion("131.0.6778.86").setup();
		WebDriver driver = new ChromeDriver();
		
		//open URL 
		driver.get("http://www.google.com");
		String actualTitle = driver.getTitle();
		String expectedTitle = "Google";
		
		Assert.assertEquals(actualTitle , expectedTitle);
		
		driver.quit();
	}
	
}
