package myPackage;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class A_10_DropDown {

	public static void main(String[] args) {

		//Launch web driver 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Selenium + Java Practise\\Drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		//open web page 
		driver.get("https://www.webfx.com/blog/web-design/50-examples-of-drop-down-navigation-menus-in-web-designs/");
		
		
		WebElement element = driver.findElement(By.xpath("//a[@class='ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only']//span[@class='ubermenu-target-title ubermenu-target-text'][normalize-space()='Who We Are']"));
		
		Select dropDown = new Select(element);
		
		//1.
		//dropDown.selectByVisibleText("Bhutan");
		
		//2. 
		//dropDown.selectByValue("98");
		
		//3. indexing starts from 0
		//dropDown.deselectByIndex(1);
		
		if(dropDown.isMultiple()==true)
		{
			System.out.println("Drop down is multipe");
		}
		else
		{
			System.out.println("Drop down is not multipe");
		}
		
		List<WebElement> alldropdownoptions = dropDown.getOptions();
		System.out.println("Total options :-"+alldropdownoptions.size());

		for(WebElement el : alldropdownoptions)
		{
			System.out.println(el.getText());
		}
		
		
		
	}

}
