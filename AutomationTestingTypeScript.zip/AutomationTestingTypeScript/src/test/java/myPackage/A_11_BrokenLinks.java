package myPackage;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_11_BrokenLinks {

	public static void main(String[] args) {
		
		//launch the browser 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
	
		WebDriver driver = new ChromeDriver();
	
		
		//Maximize browser
		driver.manage().window().maximize();
		
		//wait for 10  seconds 
		driver.manage().timeouts().implicitlyWait(10 , TimeUnit.SECONDS);
		
		//open URL
		driver.get("http://www.deadlinkcity.comm/");
		
		//FInd hyperLinks
		List<WebElement> linkList =  driver.findElements(By.tagName("a"));
		
		int resCode = 200;//2xx response code is valid link
		int brokenLinkCnt =0;
		
		System.out.println("TOtal links on page :- "+linkList.size());
		for(WebElement element:linkList)
		{
			String url = element.getAttribute("href");
			
			try {
				URL urlLink =  new URL(url);
				
				try {
					HttpURLConnection huc = (HttpURLConnection) urlLink.openConnection();
					
					huc.setRequestMethod("HEAD");
					huc.connect();
					
					resCode = huc.getResponseCode();
					
					if(resCode >= 400)
					{
						System.out.println(url+" broken list.");
						brokenLinkCnt++;
					}
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			catch(MalformedURLException e)
			{
				
			}
		}
		
		System.out.println("Total broken links :- "+brokenLinkCnt);
	}
}
