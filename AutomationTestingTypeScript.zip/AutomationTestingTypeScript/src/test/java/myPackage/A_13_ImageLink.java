package myPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A_13_ImageLink {

	public static void main(String[] args) {

		//Launch the chrome browser 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Tarun\\Desktop\\Java Eclipse Folder Path\\Demo2\\drivers\\chromedriver.exe");
		
		WebDriver driver = null;
		
		try {
		
		driver = new ChromeDriver();
		
		//max the window
		driver.manage().window().maximize();
		
		//open the url
		driver.get("https://www.opencart.com/index.php?route=common/home");
		
		//FInd thee web element and click them  
		driver.findElement(By.xpath("//img[@title='OpenCart - Open Source Shopping Cart Solution']")).click();
		
		//verify title of current page with expected home page title
		if(driver.getTitle().equals("OpenCart - Open Source Shopping Cart Solution"))
		{
			System.out.println("test Passed");
		}
		else
		{
			System.out.println("test failed");
		}
		
		  } 
        catch (Exception e) 
        {
            System.out.println("An error occurred: " + e.getMessage());
        } 
        finally 
        {
            // Close the browser, ensuring it happens even if an exception occurs
            if (driver != null) 
            {
                driver.quit();
            }
        }
	
	}

}
